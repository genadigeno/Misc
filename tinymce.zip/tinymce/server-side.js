
function uploadFile(formId, url, folder, fieldId) {
    $("#" + formId).submit(function (evt) {
        $( "#uploadForm").fadeOut('slow');
        $("#loading").html('<div class="alert alert-info">Please wait when uploading image...</div>');
        evt.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            async: true,
            cache: false,
            contentType: false,
            enctype: 'multipart/form-data',
            processData: false,
            success: function (response) {
                $( "#loading").html('');
                $( "#uploadForm").fadeIn('slow');
                $("#uploaded_images").html(response);
                $( "#uploadForm input:file:first" ).val('');
                uploaded(folder, fieldId);
            }
        });
        return false;
    });
}
function uploaded(folder, field_id) {
    $.post("/lib/tinymce/server-side/browseContent.php",
        {
            folder: folder,
            field: field_id
        },
        function(data,status){
            $("#uploaded_images").html(data);
        });
}
function delete_image(folder, filename) {
    var result = confirm("Are you sure delete " +filename+ "?");
    if (result) {
        $.post("/lib/tinymce/server-side/delete_image.php",
            {
                filename: filename,
                folder: folder
            },
            function (data, status) {
                $("#uploaded_images").prepend(data);
                uploaded(folder);
            });
    }
}
function browse(folder, field_id){
    $('#browse').modal();
    uploaded(folder, field_id);
}
function insertLink(text, field_id) {
    var input = $("#"+field_id).val(text);
    $('#browse').modal('hide');
}
////call tinymce
function callTinymce(textareaID, imageFolder, uploadScript) {
    tinymce.init({
        selector: '#'+textareaID,
        height: 500,
        theme: 'modern',
        plugins: [
            'advlist autolink lists link image charmap print preview hr anchor pagebreak lineheight',
            'searchreplace wordcount visualblocks visualchars code fullscreen',
            'insertdatetime media nonbreaking save table contextmenu directionality',
            'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
        ],
        convert_urls: false,
        toolbar1: 'undo redo | insert | styleselect  lineheightselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
        toolbar2: 'print preview media | forecolor backcolor emoticons | codesample ',
        theme_advanced_fonts : "Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n",
        lineheight_formats: "8pt 9pt 10pt 11pt 12pt 14pt 16pt 18pt 20pt 22pt 24pt 26pt 36pt",
        file_browser_callback: function(field_name, url, type, win) {
            if (type == 'image'){
                browse(imageFolder, field_name);
            }else{
                alert('no data');
            }
        },
        setup: function (editor) {
            editor.on('change', function () {
                var var2=editor.getContent({format:'html'});
                $('#'+textareaID).html(var2);
            });
        }
    });
/*
    tinymce.init({
        selector: "textarea",
        setup: function (editor) {
            editor.on('change', function () {
                editor.save();
            });
        }
    });*/
    browseImages(imageFolder);
    var field_name='';
    uploadFile('uploadForm', uploadScript, imageFolder, field_name);
}


function callTinymce_short(textareaID, imageFolder, uploadScript) {
    tinymce.init({
        selector: '#'+textareaID,
        height: 500,
        theme: 'modern',
        plugins: [
            'advlist autolink lists link charmap print preview hr anchor pagebreak lineheight',
            'searchreplace wordcount visualblocks visualchars code fullscreen',
            'insertdatetime nonbreaking save table contextmenu directionality',
            'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
        ],
        convert_urls: false,
        toolbar1: 'undo redo | insert | styleselect  lineheightselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link',
        toolbar2: 'print preview | forecolor backcolor emoticons | codesample ',
        theme_advanced_fonts : "Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n",

        lineheight_formats: "8pt 9pt 10pt 11pt 12pt 14pt 16pt 18pt 20pt 22pt 24pt 26pt 36pt",

        file_browser_callback: function(field_name, url, type, win) {

            if (type == 'image'){
                browse(imageFolder, field_name);
            }else{
                alert('no data');
            }
        },
        setup: function (editor) {
            editor.on('change', function () {
                var var2=editor.getContent({format:'html'});
                $('#'+textareaID).html(var2);
            });
        }
    });
    /*
     tinymce.init({
     selector: "textarea",
     setup: function (editor) {
     editor.on('change', function () {
     editor.save();
     });
     }
     });*/
    browseImages(imageFolder);
    var field_name='';
    uploadFile('uploadForm', uploadScript, imageFolder, field_name);
}