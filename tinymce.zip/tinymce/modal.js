function browseImages(folder) {
    document.write('<div class="modal fade" id="browse" role="dialog" style="z-index: 9999999999999999999999999999999999999999999;">\n' +
        '    <div class="modal-dialog">\n' +
        '\n' +
        '        <!-- Modal content-->\n' +
        '        <div class="modal-content">\n' +
        '            <div class="modal-header">\n' +
        '                <button type="button" class="close" data-dismiss="modal">&times;</button>\n' +
        '                <h4 class="modal-title">Browse Images</h4>\n' +
        '            </div>\n' +
        '            <div class="modal-body" style="height: 50vh; overflow-y: auto;">\n' +
        '               <div id="loading"></div> \n' +
        '                <form action="javascript:void(0)" enctype="multipart/form-data" id="uploadForm">\n' +
        '                    <div class="form-group">\n' +
        '                        <label for="image">Choose Image</label>\n' +
        '                        <input type="file" accept=".png, .jpg, .jpeg"  name="image" id="image" class="form-control">\n' +
        '                        <input type="hidden" name="folder" value="'+ folder +'">\n' +
        '                    </div>\n' +
        '                    <div class="form-group">\n' +
        '                        <button type="submit" class="btn btn-default"><i class="fa fa-upload"></i>  Upload Image</button>\n' +
        '                    </div>\n' +
        '                </form>\n' +
        '                <div class="alert alert-info">Uploaded Images</div>\n' +
        '                <div id="uploaded_images"></div>\n' +
        '            </div>\n' +
        '            <div class="modal-footer">\n' +
        '                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\n' +
        '            </div>\n' +
        '        </div>\n' +
        '\n' +
        '    </div>\n' +
        '</div>');
}