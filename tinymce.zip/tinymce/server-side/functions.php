<?php

define('is_legal',true);

require_once (dirname(__FILE__).'/../../../engine_headers.php');

$dbc = new \GL\db\sqlDB();

//$dbc->db_open($core_sql_host,$core_sql_user,$core_sql_pass,$core_sql_db);
$dbc->db_open(DB1_HOST,DB1_USER,DB1_PASS,DB1_DB);

if($dbc->connect==NULL)throw new Exception("<h2>DB connection error</h2>");

//
//$check_session=check_session();
//
//if(!$check_session)die(bo_err('AUTH ERR!!!'));

//if(!$user_data['rule_faq'])die(bo_err('AUTH ERR!!!'));

class functions{

    public function dir_scanner($var){
        $scanned_directory = array_diff(scandir($var), array('..', '.'));
        if (count($scanned_directory)>0){
            return $scanned_directory;
        }else{
            return array();
        }
    }

    public function dirNameCleaner($folder){
        $folder=explode('/', $folder);

        $newName=null;
        foreach ($folder as $item){
            if ($item!='..'){
                $newName .=$item.'/';
            }
        }
        return $newName;
    }

    public  function image ($fieldName, $newName, $folder, $width='1920', $height='1080'){
        $folder=$folder.'/';
        $expansion = explode(".", $_FILES[$fieldName]['name']);
        $fileName=$newName.'.'.strtolower(end($expansion));
        $_FILES[$fieldName]['name']=strtolower($_FILES[$fieldName]['name']);
        if (preg_match('/.jpe?g$/',$_FILES[$fieldName]['name']) && $imgc=@imagecreatefromjpeg($_FILES[$fieldName]['tmp_name']))
        {
            if (imagesx($imgc)>$width || imagesy($imgc)>$height)
            {
                $img_x=imagesx($imgc);
                $img_y=imagesy($imgc);
                if ($img_x==$img_y)
                {
                    $dstW=$width; // width
                    $dstH=$height; // height
                }
                elseif ($img_x>$img_y)
                {
                    $prop=$img_x/$img_y;
                    $dstW=$width;
                    $dstH=ceil($dstW/$prop);
                }
                else
                {
                    $prop=$img_y/$img_x;
                    $dstH=$height;
                    $dstW=ceil($dstH/$prop);
                }

                $screen=imagecreatetruecolor($dstW, $dstH);
                imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
                imagedestroy($imgc);
                @chmod($folder.$newName.".jpg",0777);
                @chmod($folder.$newName.".png",0777);
                @unlink($folder.$newName.".jpg");
                @unlink($folder.$newName.".png");
                imagejpeg($screen,$folder.$newName.".jpg",100);
                @chmod($folder.$newName.".jpg",0777);
                imagedestroy($screen);
            }
            else
            {
                copy($_FILES[$fieldName]['tmp_name'], $folder.$newName.".jpg");
            }

        }
        elseif (preg_match('/.png$/',$_FILES[$fieldName]['name']) && $imgc=@imagecreatefrompng($_FILES[$fieldName]['tmp_name']))
        {
            if (imagesx($imgc)>$width || imagesy($imgc)>$height)
            {
                $img_x=imagesx($imgc);
                $img_y=imagesy($imgc);
                if ($img_x==$img_y)
                {
                    $dstW=$width; // width
                    $dstH=$height; // height
                }
                elseif ($img_x>$img_y)
                {
                    $prop=$img_x/$img_y;
                    $dstW=$width;
                    $dstH=ceil($dstW/$prop);
                }
                else
                {
                    $prop=$img_y/$img_x;
                    $dstH=$height;
                    $dstW=ceil($dstH/$prop);
                }

                $screen=ImageCreate($dstW, $dstH);
                imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
                imagedestroy($imgc);


                @chmod($folder.$newName.".jpg",0777);
                @chmod($folder.$newName.".png",0777);
                @unlink($folder.$newName.".jpg");
                @unlink($folder.$newName.".png");
                imagepng($screen,$folder.$newName.".png");
                @chmod($folder.$newName.".png",0777);
                imagedestroy($screen);
            }
            else
            {

                copy($_FILES[$fieldName]['tmp_name'], $folder.$newName.".png");
            }
        }
        else
        {
            ///tu failis formati araa dasashvebi
            return false;

        }

        if (file_exists($folder.$fileName)){
            return $fileName;
        }else{
            return false;
        }

    }

}