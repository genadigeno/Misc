<?php

require_once ('functions.php');
if ($_SERVER['REQUEST_METHOD']=='POST'){
    if (unlink($_POST['folder'].$_POST['filename'])){
        echo '<div class="alert alert-success">Image Successfully deleted</div>';
    }else{
        echo '<div class="alert alert-danger">Image not deleted</div>';
    }
}