<?php

require_once ('functions.php');

if ($_SERVER['REQUEST_METHOD']=='POST') {
    $functions = new functions();
	ini_set('display_errors',1);
    $image=$functions->image ('image', time(), $_POST['folder']);
    if ($image){
        echo '<div class="alert alert-success">Image Successfully Uploaded</div>';
    }
    else{
        echo '<div class="alert alert-danger">Image not Uploaded</div>';
    }
}