<?php
require_once ('functions.php');
if($_POST['field']){
    $_SESSION['field']=$_POST['field'];
}
if ($_SERVER['REQUEST_METHOD']=='POST'){
    $functions=new functions();

    $dir=$functions->dirNameCleaner(dirname.filesFTPAddress.'/'.$_POST['folder']);



    $allContent=$functions->dir_scanner(dirname.filesFTPAddress.'/'.$_POST['folder']);

    echo '<div class="row">';

    if (!empty($allContent)) {
        foreach (array_reverse($allContent) as $content) {
            ?>
            <div class="col-md-4">

                <img style="width: 100%; height: 150px;"
                     src="<?= filesServerAddress.'/'.$_POST['folder'] . $content ?>"
                     onclick="insertLink('<?= filesServerAddress . $_POST['folder'] . $content ?>', '<?=$_SESSION['field']?>')">

                <button style="margin-bottom: 5px; width: 50%; float: left;"
                        onclick="insertLink('<?= filesServerAddress. $_POST['folder'] . $content?>', '<?=$_SESSION['field']?>')"
                        class="form-control btn-success"><i class="fa fa-pencil"></i> Insert
                </button>

                <button style="margin-bottom: 5px; width: 50%; float: left;"
                        onclick="delete_image('<?= $_POST['folder'] ?>', '<?= $content ?>')"
                        class="form-control btn-danger"><i class="fa fa-trash"></i> Delete
                </button>

            </div>
            <?php
        }
    }else{
        echo '<h3 class="text-center">You have not images</h3>';
    }
    echo '</div>';
}